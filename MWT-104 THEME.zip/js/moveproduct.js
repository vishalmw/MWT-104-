
    function next(){
    var imegs=document.getElementById("imeges");
var imgs=document.getElementById("shoes").innerHTML=imegs;

console.log(imgs);

    }
